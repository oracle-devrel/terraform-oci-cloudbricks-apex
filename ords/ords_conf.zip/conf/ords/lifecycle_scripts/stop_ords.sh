#!/bin/sh

sudo kill -9 $(ps aux | grep "java" | grep -v 'grep' | awk '{print $2}')