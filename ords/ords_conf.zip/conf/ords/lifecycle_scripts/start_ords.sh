#!/bin/sh

java -jar -Duser.timezone=UTC -Djava.net.preferIPv4Stack=true /opt/oracle/ords/ords.war standalone > /opt/oracle/ords/ords_server.log 2>&1